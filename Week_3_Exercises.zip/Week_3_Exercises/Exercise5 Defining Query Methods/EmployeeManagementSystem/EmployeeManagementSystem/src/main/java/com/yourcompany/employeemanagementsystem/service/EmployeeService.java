package com.yourcompany.employeemanagementsystem.service;

import com.yourcompany.employeemanagementsystem.entity.Employee;
import com.yourcompany.employeemanagementsystem.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    public List<Employee> getEmployeesByDepartment(Long departmentId) {
        return employeeRepository.findByDepartment(departmentId);
    }

    public long countEmployeesWithSalaryGreaterThan(Double salary) {
        return employeeRepository.countBySalaryGreaterThan(salary);
    }
}




