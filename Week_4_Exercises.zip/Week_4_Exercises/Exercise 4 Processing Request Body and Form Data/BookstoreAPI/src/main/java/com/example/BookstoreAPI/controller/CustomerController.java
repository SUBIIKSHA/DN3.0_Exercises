package com.example.BookstoreAPI.controller;

import com.example.BookstoreAPI.entity.Customer;
import com.example.BookstoreAPI.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @PostMapping("/register")
    public ResponseEntity<Customer> registerCustomer(@RequestBody Customer customer) {
        Customer createdCustomer = customerService.createCustomer(customer);
        return new ResponseEntity<>(createdCustomer, HttpStatus.CREATED);
    }

    @PostMapping("/register/form")
    public ResponseEntity<Customer> registerCustomerForm(@RequestParam Map<String, String> formData) {
        System.out.println("Form Data: " + formData);
        Customer customer = new Customer();
        customer.setName(formData.get("name"));
        customer.setEmail(formData.get("email"));
        customer.setPhone(formData.get("phone"));
        Customer createdCustomer = customerService.createCustomer(customer);
        return new ResponseEntity<>(createdCustomer, HttpStatus.CREATED);
    }
}
