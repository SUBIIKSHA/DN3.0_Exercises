package com.example.BookstoreAPI.service;

import com.example.BookstoreAPI.dto.BookDTO;
import com.example.BookstoreAPI.entity.Book;
import com.example.BookstoreAPI.repository.BookRepository;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookService {

    @Autowired
    private BookRepository bookRepository;

    private final Counter booksAddedCounter;
    private final Counter booksUpdatedCounter;
    private final Counter booksDeletedCounter;

    public BookService(MeterRegistry meterRegistry) {
        this.booksAddedCounter = meterRegistry.counter("books.added");
        this.booksUpdatedCounter = meterRegistry.counter("books.updated");
        this.booksDeletedCounter = meterRegistry.counter("books.deleted");
    }

    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }

    public Optional<Book> getBookById(Long id) {
        return bookRepository.findById(id);
    }

    public Book saveBook(Book book) {
        Book savedBook = bookRepository.save(book);
        booksAddedCounter.increment();
        return savedBook;
    }

    public Book updateBook(Long id, BookDTO bookDTO) {
        Optional<Book> optionalBook = bookRepository.findById(id);
        if (optionalBook.isPresent()) {
            Book book = optionalBook.get();
            book.setTitle(bookDTO.getTitle());
            book.setAuthor(bookDTO.getAuthor());
            book.setPrice(bookDTO.getPrice());
            book.setIsbn(bookDTO.getIsbn());
            Book updatedBook = bookRepository.save(book);
            booksUpdatedCounter.increment();
            return updatedBook;
        } else {
            return null;
        }
    }

    public boolean deleteBook(Long id) {
        if (bookRepository.existsById(id)) {
            bookRepository.deleteById(id);
            booksDeletedCounter.increment();
            return true;
        } else {
            return false;
        }
    }
}
