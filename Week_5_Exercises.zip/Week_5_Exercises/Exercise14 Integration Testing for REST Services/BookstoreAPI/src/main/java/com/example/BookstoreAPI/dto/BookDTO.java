package com.example.BookstoreAPI.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import org.springframework.hateoas.RepresentationModel;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "book")
public class BookDTO {

        @NotNull
        @Size(min = 1, max = 255)
        private String title;

        @NotNull
        @Size(min = 1, max = 255)
        private String author;

        @NotNull
        @Min(value = 0)
        private Double price;

        @NotNull
        @Size(min = 10, max = 13)
        private String isbn;
        private Long id;

    @XmlElement
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    @XmlElement
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    @XmlElement
    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }

    @XmlElement
    public Double getPrice() { return price; }
    public void setPrice(Double price) { this.price = price; }

    @XmlElement
    public String getIsbn() { return isbn; }
    public void setIsbn(String isbn) { this.isbn = isbn; }
}
