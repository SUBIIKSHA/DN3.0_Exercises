package MVCPatternExample;

public class MVCPatternExample {
    public static void main(String[] args) {
        Student model = new Student("Subiksha", "150", "O");

        StudentView view = new StudentView();

        StudentController controller = new StudentController(model, view);

        controller.updateView();

        controller.setStudentName("Harshini");
        controller.setStudentId("462");
        controller.setStudentGrade("B");

        controller.updateView();
    }
}
