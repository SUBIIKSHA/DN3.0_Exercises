package DecoratorPatternExample;

public class TestDecoratorPattern {
    public static void main(String[] args) {
        Notifier notifier = new EmailNotifier();
        System.out.println("Sending email notification:");
        notifier.send("Hello");

        System.out.println("\nAdding SMS Notifier:");
        Notifier smsNotifier = new SMSNotifierDecorator(notifier);
        System.out.println("Sending email and SMS notifications:");
        smsNotifier.send("Hello");

        System.out.println("\nAdding Slack Notifier:");
        Notifier slackNotifier = new SlackNotifierDecorator(smsNotifier);
        System.out.println("Sending email, SMS, and Slack notifications:");
        slackNotifier.send("Hello");
    }
}
