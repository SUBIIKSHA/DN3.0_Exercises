package SingletonPatternExample;

public class LoggerTest {
    public static void main(String[] args) {

        Logger logger1 = Logger.getInstance();
        Logger logger2 = Logger.getInstance();

        if (logger1 == logger2) {
            System.out.println("Singleton check: Logger instance is the same");
        } else {
            System.out.println("Singleton check failed");
        }

        logger1.log("First log message.");
        logger2.log("Second log message.");
    }
}