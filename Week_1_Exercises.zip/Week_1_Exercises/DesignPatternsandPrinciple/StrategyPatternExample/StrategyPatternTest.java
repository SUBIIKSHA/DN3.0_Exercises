package StrategyPatternExample;

public class StrategyPatternTest {
    public static void main(String[] args) {
        PaymentContext paymentContext = new PaymentContext(null);

        PaymentStrategy creditCardPayment = new CreditCardPayment("1234-5678-9824-5632", "Subiksha");
        paymentContext.setPaymentStrategy(creditCardPayment);
        paymentContext.pay(280.0);

        PaymentStrategy payPalPayment = new PayPalPayment("subiksha@gmail.com");
        paymentContext.setPaymentStrategy(payPalPayment);
        paymentContext.pay(799.0);
    }
}