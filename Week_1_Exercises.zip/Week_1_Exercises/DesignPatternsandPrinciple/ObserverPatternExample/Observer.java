package ObserverPatternExample;

public interface Observer {
    void update(double price);
}
