package CommandPatternExample;

public class Fan {
    private boolean isOn;

    public void turnOn() {
        isOn = true;
        System.out.println("The fan is on.");
    }

    public void turnOff() {
        isOn = false;
        System.out.println("The fan is off.");
    }
}
