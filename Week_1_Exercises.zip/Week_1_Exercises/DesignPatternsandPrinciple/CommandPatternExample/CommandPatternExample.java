package CommandPatternExample;

public class CommandPatternExample {
    public static void main(String[] args) {
        Fan livingRoomFan = new Fan();
        Command fanOn = new FanOnCommand(livingRoomFan);
        Command fanOff = new FanOffCommand(livingRoomFan);

        RemoteControl remote = new RemoteControl();

        remote.setCommand(fanOn);
        remote.pressButton();

        remote.setCommand(fanOff);
        remote.pressButton();
    }
}