package BuilderPatternExample;

public class Computer {
    private final String cpu;
    private final String ram;

    private final String storage;
    private final String gpu;

    private Computer(Builder builder) {
        this.cpu = builder.cpu;
        this.ram = builder.ram;
        this.storage = builder.storage;
        this.gpu = builder.gpu;
    }

    public String getCpu() {
        return cpu;
    }

    public String getRam() {
        return ram;
    }

    public String getStorage() {
        return storage;
    }

    public String getGpu() {
        return gpu;
    }

    public static class Builder {
        private final String cpu;
        private final String ram;

        private String storage = "512GB SSD";
        private String gpu = "NVIDIA GTX 1050";

        public Builder(String cpu, String ram) {
            this.cpu = cpu;
            this.ram = ram;
        }

        public Builder storage(String storage) {
            this.storage = storage;
            return this;
        }

        public Builder gpu(String gpu) {
            this.gpu = gpu;
            return this;
        }

        public Computer build() {
            return new Computer(this);
        }
    }

    public static class TestComputerBuilder {
        public static void main(String[] args) {
            Computer computer1 = new Computer.Builder("Intel i9", "32GB")
                    .storage("2TB SSD")
                    .gpu("NVIDIA RTX 3080")
                    .build();

            Computer computer2 = new Computer.Builder("AMD Ryzen 7", "16GB")
                    .build();

            System.out.println("Computer 1 - CPU: " + computer1.getCpu() +
                    ", RAM: " + computer1.getRam() +
                    ", Storage: " + computer1.getStorage() +
                    ", GPU: " + computer1.getGpu());

            System.out.println("Computer 2 - CPU: " + computer2.getCpu() +
                    ", RAM: " + computer2.getRam() +
                    ", Storage: " + computer2.getStorage() +
                    ", GPU: " + computer2.getGpu());
        }
    }
}
