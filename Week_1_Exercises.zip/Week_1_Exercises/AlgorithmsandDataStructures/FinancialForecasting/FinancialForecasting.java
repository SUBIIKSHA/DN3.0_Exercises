package FinancialForecasting;

import java.util.HashMap;

public class FinancialForecasting {

    private static HashMap<Integer, Double> memo = new HashMap<>();

    public static double futureValue(double initialValue, double growthRate, int years) {
        if (years == 0) {
            return initialValue;
        }
        if (memo.containsKey(years)) {
            return memo.get(years);
        }
        double result = futureValue(initialValue * (1 + growthRate), growthRate, years - 1);
        memo.put(years, result);
        return result;
    }

    public static void main(String[] args) {
        double initialValue = 2000;
        double growthRate = 0.05;
        int years = 5;

        double futureVal = futureValue(initialValue, growthRate, years);
        System.out.println("The future value of the investment is: $" + futureVal);
    }
}
