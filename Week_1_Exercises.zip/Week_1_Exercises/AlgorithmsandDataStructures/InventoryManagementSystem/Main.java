package InventoryManagementSystem;

public class Main {
    public static void main(String[] args) {
        Inventory ims = new Inventory();

        Product p1 = new Product("1", "Mobilephone", 12, 10000);
        Product p2 = new Product("2", "Airpods", 23, 1000);
        Product p3 = new Product("3", "Tablet", 10, 5000);

        ims.addProduct(p1);
        ims.addProduct(p2);
        ims.addProduct(p3);

        System.out.println("All products:");
        ims.displayAllProducts();

        Product p2Updated = new Product("2", "Airpods", 20, 400);
        ims.updateProduct("2", p2Updated);

        System.out.println("\nAfter update:");
        ims.displayAllProducts();

        ims.deleteProduct("003");

        System.out.println("\nAfter deletion:");
        ims.displayAllProducts();

        Product p = ims.getProduct("001");
        System.out.println("\nRetrieved product:");
        System.out.println(p);
    }
}