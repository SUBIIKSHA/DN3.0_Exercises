package SortingCustomerOrders;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Order[] orders = {
                new Order(1, "Hari", 493.20),
                new Order(2, "Mithun", 134.67),
                new Order(3, "Charu", 342.86),
                new Order(4, "Darshu", 120.35),
                new Order(5, "Iyan", 110.00)
        };

        System.out.println("Original Orders:");
        printOrders(orders);

        Order[] bubbleSortedOrders = Arrays.copyOf(orders, orders.length);
        BubbleSort.bubbleSort(bubbleSortedOrders);
        System.out.println("\nOrders Sorted by Bubble Sort:");
        printOrders(bubbleSortedOrders);

        Order[] quickSortedOrders = Arrays.copyOf(orders, orders.length);
        QuickSort.quickSort(quickSortedOrders, 0, quickSortedOrders.length - 1);
        System.out.println("\nOrders Sorted by Quick Sort:");
        printOrders(quickSortedOrders);
    }

    private static void printOrders(Order[] orders) {
        for (Order order : orders) {
            System.out.println("Order ID: " + order.getOrderId() +
                    ", Customer Name: " + order.getCustomerName() +
                    ", Total Price: " + order.getTotalPrice());
        }
    }
}
