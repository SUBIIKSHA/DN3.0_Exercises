package EmployeeManagementSystem;

import java.util.Arrays;

public class EmployeeManagementSystem {
    private Employee[] employees;
    private int size;

    public EmployeeManagementSystem(int capacity) {
        employees = new Employee[capacity];
        size = 0;
    }

    public boolean addEmployee(Employee employee) {
        if (size >= employees.length) {
            return false;
        }
        employees[size++] = employee;
        return true;
    }

    public Employee searchEmployee(int employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].employeeId == employeeId) {
                return employees[i];
            }
        }
        return null;
    }

    public void traverseEmployees() {
        for (int i = 0; i < size; i++) {
            System.out.println(employees[i]);
        }
    }

    public boolean deleteEmployee(int employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].employeeId == employeeId) {
                for (int j = i; j < size - 1; j++) {
                    employees[j] = employees[j + 1];
                }
                employees[--size] = null;
                return true;
            }
        }
        return false;
    }

    public static void main(String[] args) {
        EmployeeManagementSystem ems = new EmployeeManagementSystem(10);

        ems.addEmployee(new Employee(1, "Hasini", "Tester", 67900));
        ems.addEmployee(new Employee(2, "Babu", "Developer", 75000));
        ems.addEmployee(new Employee(3, "Surya", "Analyst", 88000));

        System.out.println("Listing all employees:");
        ems.traverseEmployees();

        System.out.println("\nFinding employee with ID 2:");
        Employee foundEmployee = ems.searchEmployee(2);
        if (foundEmployee != null) {
            System.out.println("Found: " + foundEmployee);
        } else {
            System.out.println("Employee with ID 2 not found");
        }

        System.out.println("\nRemoving employee with ID 2:");
        boolean isDeleted = ems.deleteEmployee(2);
        System.out.println("Removal status: " + isDeleted);

        System.out.println("\nEmployees after removal:");
        ems.traverseEmployees();
    }
}