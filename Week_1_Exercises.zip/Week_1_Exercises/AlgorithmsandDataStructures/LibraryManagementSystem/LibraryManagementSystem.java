package LibraryManagementSystem;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class LibraryManagementSystem {
    public static void main(String[] args) {
        List<Book> books = new ArrayList<>();
        books.add(new Book(1, "The Hobbit", "J.R.R. Tolkien"));
        books.add(new Book(2, "War and Peace", "Leo Tolstoy"));
        books.add(new Book(3, "The Odyssey", "Homer"));
        books.add(new Book(4, "Pride and Prejudice", "Jane Austen"));
        books.add(new Book(5, "Moby Dick", "Herman Melville"));

        Book foundBook = linearSearchByTitle(books, "The Odyssey");
        System.out.println("Linear Search: " + foundBook);

        foundBook = binarySearchByTitle(books, "Moby Dick");
        System.out.println("Binary Search: " + foundBook);
    }

    public static Book linearSearchByTitle(List<Book> books, String title) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null;
    }

    public static Book binarySearchByTitle(List<Book> books, String title) {
        Collections.sort(books, Comparator.comparing(Book::getTitle, String.CASE_INSENSITIVE_ORDER));

        int left = 0;
        int right = books.size() - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            Book midBook = books.get(mid);
            int compareResult = midBook.getTitle().compareToIgnoreCase(title);

            if (compareResult == 0) {
                return midBook;
            } else if (compareResult < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }
}
